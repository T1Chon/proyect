import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ServicesService } from '../services/services.service';
import { product } from '../interfaces/productos.module';
import { ReactiveFormsModule } from '@angular/forms';


@Component({
  selector: 'app-admin',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './admin.component.html',
  styleUrl: './admin.component.css'
})
export class AdminComponent {

  productForm: FormGroup;
 
  constructor(private fb: FormBuilder, private ServicesService: ServicesService) {
    this.productForm = this.fb.group({
      referencia: ['', Validators.required],
      nombre: ['', Validators.required],
      precio: ['', Validators.required],
      descripcion: ['', Validators.required],
      imagen: ['']
    });
  }
 
  insertarProducto(): void {
    if (this.productForm.valid) {
      const newProduct: product = this.productForm.value;
      this.ServicesService.sendProduct(newProduct);
      this.productForm.reset();
    }
  }
}
