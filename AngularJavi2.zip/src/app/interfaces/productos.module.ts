export interface product {
    referencia: string;
    nombre: string;
    precio: number;
    descripcion: string;
    imagen: string;
  }