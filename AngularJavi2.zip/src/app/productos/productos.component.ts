import { Component, importProvidersFrom } from '@angular/core';
import {product} from '../interfaces/productos.module';
import { ServicesService } from '../services/services.service';

@Component({
  selector: 'app-productos',
  standalone: true,
  imports: [],
  templateUrl: './productos.component.html',
  styleUrl: './productos.component.css'
})
export class ProductosComponent {
products: product[] = [];
 
  constructor(private ServicesService: ServicesService) {}
 
  ngOnInit(): void {
    this.ServicesService.getProducts().subscribe((products: product[]) => {
      this.products = products;
    });
  }
}
